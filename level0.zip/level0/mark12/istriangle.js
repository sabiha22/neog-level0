const inputs=document.querySelectorAll('.angle-input');
const isTriangleBtn= document.querySelector("#check-triangle");
const output= document.querySelector('#output');

function calculateSum(angle1,angle2,angle3){
    const sumOfAngles= angle1+angle2+angle3;
    //console.log(sumOfAngles);
    return sumOfAngles;
}

function isTriangle(){
    const sumOfAngles= calculateSum(Number(inputs[0].value),Number(inputs[1].value),Number(inputs[2].value),)
    //console.log(inputs[0].value, inputs[1].value, inputs[2].value,)
    if(sumOfAngles===180){
        output.innerText="This is a triangle";
    }
    else    
        output.innerText="Not a triangle";
}

isTriangleBtn.addEventListener("click", isTriangle);