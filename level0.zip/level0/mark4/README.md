# practice-lesson03

Comp

## brand colors

- Primary Color
- Primary Dark?
- Gray

## typography

- h1,
- h2,
- text
- text-sm

## container

- fluid
- center

## button

- Primary Button
- Secondary Button

## nav

- Brand
- Link

## header

- image
- heading

## section

## Lists

- Ordered List
- Unordered List

## footer

- heading
- Link
